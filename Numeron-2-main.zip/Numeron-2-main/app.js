//link the play button
const playButton=document.getElementById("play-button");
playButton.onclick=()=>{
    location.href="./game.html";
}